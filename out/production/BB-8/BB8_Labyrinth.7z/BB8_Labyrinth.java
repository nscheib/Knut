/* IMPORT */
import java.util.*;
/**/

/**
 * Ein Programm bei dem ein Bot, mithilfe der Rechten-Hand-Regel durch ein Labyrinth laeuft.
 * @author Christian Clausen
 * @author Nick Scheib
 * @Version 0.99
 */

/* CLASS */
public class BB8_Labyrinth extends IndexOutOfBoundsException{


    /* MAINMETHODE */
    public static void main(String[] args)  {

        // Konstanten und Variablen
        final char RECHTS = '˃';
        final char LINKS = '˂';
        final char OBEN = '˄';
        final char UNTEN = '˅'; 

        char blickRichtung = '0';

        int botPosY = 6;
        int botPosX = 0;

        int wahlDesLabyrinths;
        boolean richtig = false;

        boolean ausgangGefunden = false;

        final char WAND = '#';
        char ausgang = 'A';
        char start = 'S';
        char weg = ' ';


        // Array zum abspeichern des gewählten Labyrinths
        char[][] labyrinth = new char[20][20];


        System.out.println("");
        System.out.print("Bei diesem kleinen Spiel kannst du zusehen, wie ein kleiner Roboter  Namens BB-8, \n" +
                "selbstständig ein Rätsel löst. \n" +
                "Alles was du dafür tun musst, ist eins von drei Labyrinthen zu wählen und dem kleinen Bot \n" +
                "zuzusehen wie der das Labyrinth eigenständig löst. \n");
        System.out.println("");


        //Scanner für die Eingabe
        Scanner scanner = new Scanner(System.in);


        System.out.print("Es stehen drei Labyrinthe zur Auswahl. Gib 1, 2 oder 3 ein, um ein Labyrinth zu wählen:");
        wahlDesLabyrinths = scanner.nextInt();
        System.out.println("");

        while (!richtig){
            if (wahlDesLabyrinths <= 0 || wahlDesLabyrinths > 3) {
                System.out.println("Fehler! Gib eine Zahl zwischen 1 und 3 ein!");
                wahlDesLabyrinths = scanner.nextInt();
            } else{
                richtig = true;
            }
        }
        if (wahlDesLabyrinths == 1){
                // Initialisierung des Labyrinth
                char[][] labyrinthEins = {
                        { WAND, WAND, WAND, WAND, WAND, WAND, WAND, WAND, WAND, WAND, WAND },
                        { WAND, weg, weg, weg, WAND, weg, weg, weg, weg, weg, WAND },
                        { WAND, WAND, weg, WAND, WAND, weg, WAND, weg, WAND, weg, WAND },
                        { WAND, weg, weg, WAND, weg, weg, WAND, weg, WAND, weg, WAND },
                        { WAND, weg, weg, weg, weg, weg, WAND, weg, WAND, weg, ausgang },
                        { WAND, weg, WAND, weg, WAND, weg, WAND, weg, weg, weg, WAND },
                        { start, weg, WAND, weg, WAND, WAND, WAND, weg, WAND, weg, WAND },
                        { WAND, weg, WAND, weg, weg, weg, WAND, weg, WAND, weg, WAND },
                        { WAND, weg, WAND, WAND, WAND, weg, WAND, weg, weg, weg, WAND },
                        { WAND, WAND, WAND, weg, WAND, WAND, WAND, WAND, WAND, WAND, WAND }
                };
                labyrinth = labyrinthEins;

        } else if (wahlDesLabyrinths == 2){
                // Initialisierung des Labyrinth
                char[][] labyrinthZwei = {
                        {WAND, WAND, WAND, WAND, WAND, WAND, WAND, WAND, WAND, WAND, WAND, WAND, WAND, WAND, WAND, WAND},
                        {WAND,  weg, weg, weg, WAND, weg, weg, weg, weg, weg, weg, weg, weg, weg, WAND, WAND},
                        {WAND, WAND, weg, WAND, WAND, weg, WAND, weg, WAND, weg, WAND, weg, WAND, weg, weg, WAND},
                        {WAND,  weg, weg, WAND, weg, weg, WAND, weg, WAND, weg, WAND, weg, WAND, weg, WAND, WAND},
                        {WAND,  weg, weg, weg, weg, weg, WAND, weg, WAND, weg, WAND, weg, WAND, weg, weg, ausgang},
                        {WAND,  weg, WAND, weg, WAND, weg, WAND, weg, weg, weg, weg, weg, WAND, WAND, weg, WAND},
                        {start,  weg, WAND, weg, WAND, WAND, WAND, weg, WAND, weg, WAND, WAND, WAND, WAND, WAND, WAND},
                        {WAND,  weg, WAND, weg, weg, weg, WAND, weg, WAND, weg, WAND, weg, weg, weg, WAND, WAND},
                        {WAND, weg, WAND, WAND, WAND, weg, WAND, weg, WAND, weg, WAND, weg, WAND, weg, WAND, WAND},
                        {WAND,  weg, WAND, weg, WAND, WAND, WAND, WAND, WAND, WAND, WAND, weg, WAND, weg, weg, WAND},
                        {WAND,  weg, WAND, weg, WAND, WAND, WAND, weg, weg, weg, weg, weg, WAND, weg, WAND, WAND},
                        {WAND,  weg, WAND, weg, weg, weg, weg, WAND, weg, WAND, weg, weg, WAND, weg, WAND, WAND},
                        {WAND,  weg, weg, weg, WAND, WAND, weg, weg, weg, WAND, WAND, WAND, weg, weg, weg, WAND},
                        {WAND, WAND, WAND, WAND, WAND, WAND, WAND, WAND, WAND, WAND, WAND, WAND, WAND, WAND, WAND, WAND}
                };
                labyrinth = labyrinthZwei;

        }else if (wahlDesLabyrinths == 3){
                /// Initialisierung des Labyrinth
                char[][] labyrinthDrei = {
                        {WAND, WAND, weg, weg, weg, weg, WAND,WAND,WAND,weg, weg, weg, weg, WAND, WAND},
                        {WAND, weg, weg, weg, weg, WAND,weg, weg, weg, WAND,weg, weg, weg, weg, WAND},
                        {weg, weg, weg, weg, WAND,weg, weg, WAND,weg, weg, WAND,weg, weg, weg, weg},
                        {weg, weg, weg, WAND,weg, weg, WAND,WAND, WAND, weg, weg, WAND,weg, weg, weg},
                        {weg, weg, WAND,weg, weg, WAND,weg, WAND, weg, WAND, weg, weg, WAND,weg, weg},
                        {WAND, WAND,weg, weg, WAND,weg, weg, WAND, weg, weg, WAND, weg, weg, WAND,WAND},
                        {start,weg,weg, WAND,weg, WAND, WAND, WAND, WAND, WAND, WAND, WAND, weg, weg, ausgang},
                        {WAND, WAND,weg, weg, WAND,weg, weg, WAND, weg, weg, WAND, weg, weg, WAND,WAND},
                        {weg, weg, WAND,weg, weg, WAND,weg, WAND, weg, WAND, weg, weg, WAND,weg, weg},
                        {weg, weg, weg, WAND, weg,weg, WAND,WAND, WAND, weg, weg, WAND,weg, weg, weg},
                        {weg, weg, weg, weg, WAND,weg, weg, WAND,weg, weg, WAND,weg, weg, weg, weg},
                        {WAND, weg, weg, weg, weg, WAND,weg, WAND,weg, WAND,weg, weg, weg, weg, WAND},
                        {WAND, WAND, weg, weg, weg, weg, WAND,WAND,WAND,weg, weg, weg, weg, WAND, WAND}
                };
                labyrinth = labyrinthDrei;
        }

        // Ausgabe Labyrinth
        printLabyrinth(labyrinth);

        // Zum berechnen der Botposition
        int[] botPosition = { botPosY, botPosX };

        // Initialisierung einer Karte um die Positionen des Bots abzuspeichern
        char[][] botPositionsKarte = createCopyOfMap(labyrinth);

        blickRichtung = RECHTS;

        while(!ausgangGefunden){
            // Verzögerung

            try{
                Thread.sleep(500);
            }catch(InterruptedException e){
                e.printStackTrace();
            }

            if (labyrinth[botPosY][botPosX] == 'A'){
                ausgangGefunden = true;
                System.out.println("Der BB-2 ist diesen Weg gelaufen: ");
                printLabyrinth(botPositionsKarte);
                continue;
            }

            switch (blickRichtung) {
                case RECHTS:
                    if (labyrinth[botPosY + 1][botPosX] == WAND) {
                        blickRichtung = OBEN;
                        break;
                    } else {
                        blickRichtung = UNTEN;
                        botPosY = botPosY + 1;
                        botPositionsKarte[botPosY][botPosX] = blickRichtung;
                        botPosition[0] = botPosY;
                        break;
                    }
                case LINKS:
                    if (labyrinth[botPosY - 1][botPosX] == WAND) {
                        blickRichtung = UNTEN;
                        break;
                    } else {
                        blickRichtung = OBEN;
                        botPosY = botPosY - 1;
                        botPositionsKarte[botPosY][botPosX] = blickRichtung;
                        botPosition[0] = botPosY;
                        break;
                    }
                case OBEN:
                    if (labyrinth[botPosY][botPosX + 1] == WAND) {
                        blickRichtung = LINKS;
                        break;
                    } else {
                        blickRichtung = RECHTS;
                        botPosX = botPosX + 1;
                        botPositionsKarte[botPosY][botPosX] = blickRichtung;
                        botPosition[1] = botPosX;
                        break;
                    }
                case UNTEN:
                    if (labyrinth[botPosY][botPosX - 1] == WAND) {
                        blickRichtung = RECHTS;
                        break;
                    } else {
                        blickRichtung = LINKS;
                        botPosX = botPosX - 1;
                        botPositionsKarte[botPosY][botPosX] = blickRichtung;
                        botPosition[1] = botPosX;
                        break;
                    }
            }

            char[][] copy = createCopyOfMap(labyrinth);
            copy[botPosition[0]][botPosition[1]] = blickRichtung;
            printLabyrinth(copy);
            System.out.print("\n");

        }

    } // END MAINMETHODE




/* METHODEN ----------------------------------------------------------------------------------------------------------*/

    /**
     * Methode, gibt des Labyrinth in der Console aus
     * @param labyrinth ist das Array, aus dem die Daten stammen
     */
    public static void printLabyrinth(char[][] map){
        String labyrith = "";
        // Ausgabe Labyrinth
        for (int zeile = 0; zeile < map.length; zeile++) {
            if (map[zeile][0] == '\u0000') continue;
            String line = "";
            for (int spalte = 0; spalte < map[zeile].length; spalte++) {
                //System.out.print(map[zeile][spalte] + " ");
                line += map[zeile][spalte] + " ";
            }
            line += "\n";
            labyrith += line;
        }
        System.out.println(labyrith);
    }// END printLabyrinth

    public static char[][] createCopyOfMap(char[][] map) {
        char[][] copy = new char[20][20];
        for (int i = 0; i < map.length; i++) {
            char[] line = new char[20];
            for (int j = 0; j < map[i].length; j++) {
                line[j] = map[i][j];
            }
            copy[i] = line;
        }
        return copy;
    }
    
} // END CLASS